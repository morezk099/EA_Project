import tkinter as tk
from tkinter import ttk, messagebox
import random
import math
import matplotlib.pyplot as pl
from collections import defaultdict  

students = {
    "level1_1": ["Introduction to Computers", "Physics", "Mathematics-1", "Probability and Statistics-1",
                 "Fundamentals of Information Systems", "English-1"],
    "level1_2": ["Programming-1", "Mathematics-2", "Electronics", "Probability and Statistics-2", "Internet Technology",
                 "English-2"],
    "level2_1": ["Logic Design", "Programming-2", "Data Structures", "Data Communication", "Database System-1",
                 "System Analysis and Design-1"],
    "level2_2": ["Software Engineering-1", "Algorithms", "Operating Systems-1", "Computer Networks-1",
                 "Discrete Mathematics", "Signals and Systems"],
    "level3_1": ["Artificial Intelligence", "Convex Optimization Theory", "Machine Learning", "Big Data Technologies",
                 "Database Systems-2", "Image processing-1"],
    "level3_2": ["Evolutionary Algorithm", "Natural Language Processing", "Advanced Machine Learning", "Robotics",
                 "Computer Vision", "Speech Processing"],
    "level4_1": ["Neural Networks & deep learning", "Introduction to Data Science",
                 "Parallel Processing and High Performance Computing", "Digital Signal Processing", "Professional Ethics",
                 "Project-1"],
    "level4_2": ["Natural Language Understanding", "Computational Intelligence", "Microprocessors",
                 "Distributed Systems and Cloud Computing", "Fundamentals of Economics", "Project-2"],
}

days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday']
times = ['8', '10', '12', '2', '4']
rooms = ['hall1', 'hall2', 'hall17', 'hall14', 'hall6a', 'hall6b']

subject_prof = {}
subject_lecs = {}


def create_schedule_indvidual(sessions):
    sched = []
    for subj in sessions:
        # Find level
        level = next(
            int(key.split('_')[0][5:])  # Extract level from key (e.g., "level1_1" → 1)
            for key in students 
            if subj in students[key]
        )
        
        sched.append({
            "Subject": subj,
            "Professor": subject_prof.get(subj, "TBD"),
            "Level": level,
            "Day": random.choice(days),
            "Time": random.choice(times),
            "Room": random.choice(rooms)
        })
    return sched


def create_population(popsize, sessions):
    return [create_schedule_indvidual(sessions) for _ in range(popsize)]

from collections import defaultdict

def fitness(sched):
    pen, seen = 0, set()
    level_time_courses = defaultdict(set)  # {(level,day,time): {course1, course2}}
    
    for entry in sched:
        # Find which level this course belongs to
        course = entry['Subject']
        level = next(
            int(key.split('_')[0][5:])  # Extract from "levelX_Y"
            for key in students 
            if course in students[key]
        )
        
        # Check for same-level conflicts
        time_slot = (level, entry['Day'], entry['Time'])
        if course in level_time_courses[time_slot]:
            pen += 0.8  # Same course scheduled twice
        elif len(level_time_courses[time_slot]) > 0:
            pen += 0.5  # Different courses at same level/time
        level_time_courses[time_slot].add(course)
        
        # Original constraints
        k1 = (entry['Day'], entry['Time'], entry['Room'])
        k2 = (entry['Day'], entry['Time'], entry['Professor'])
        pen += (k1 in seen) + (k2 in seen)
        seen.update({k1, k2})
        
        if entry['Time'] in [ '4']:
            pen += 0.3
            
    return -pen

def tournament_selection(population, tournament_size=5):
    tournament = random.sample(population, tournament_size)
    return max(tournament, key=fitness)


def crossover(a, b):
    return [random.choice([a[i], b[i]]).copy() for i in range(len(a))]


def mutate(sched):
    i = random.randrange(len(sched))
    gene = sched[i]
    if random.random() < 0.33:
        gene['Day'] = random.choice(days)
    elif random.random() < 0.66:
        gene['Time'] = random.choice(times)
    else:
        gene['Room'] = random.choice(rooms)
    return sched

def run_ga(sessions, gens=100, pop_size=200, mutation_rate=0.2):
    pop = create_population(pop_size, sessions)
    best_fitness_per_gen = []

    for generation in range(gens):
        pop.sort(key=fitness, reverse=True)
        current_best = pop[0]
        current_fitness = fitness(current_best)
        best_fitness_per_gen.append(current_fitness)

        print(f"Generation {generation}: Best Fitness = {current_fitness}")
        

        if current_fitness == 0:  # Perfect score
            print("Optimal solution found early")
            break

        new_pop = [pop[0]]  # Elitism
        while len(new_pop) < pop_size:
            parent1 = tournament_selection(pop)
            parent2 = tournament_selection(pop)
            child = crossover(parent1, parent2)
            if random.random() < mutation_rate:
                child = mutate(child)
            new_pop.append(child)
        pop = new_pop
    return pop[0], best_fitness_per_gen

class ScrollableFrame(ttk.Frame):
    def __init__(self, container, *args, **kwargs):
        super().__init__(container, *args, **kwargs)
        self.all_entries = []  # Add with other instance variables
        self.canvas = tk.Canvas(self)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = ttk.Frame(self.canvas)
        self.scrollable_window = self.canvas.create_window(
            (0, 0), window=self.scrollable_frame, anchor="nw")
        self.scrollable_frame.bind("<Configure>", self._configure_scrollregion)
        self.canvas.bind("<Configure>", self._configure_window_size)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self.scrollbar.pack(side="right", fill="y")
    def _configure_scrollregion(self, event):
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
    def _configure_window_size(self, event):
        self.canvas.itemconfig(self.scrollable_window, width=event.width)
class TimetableApp:
    def __init__(self, root):
        self.root = root
        root.title("University Timetable Generator")
        root.geometry("1000x800")
        main_frame = ttk.Frame(root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)
        self.semester_var = tk.StringVar(value="1")
        ttk.Label(main_frame, text="Select Semester:").grid(row=0, column=0, sticky="w")
        ttk.Radiobutton(main_frame, text="Semester 1", variable=self.semester_var,
                        value="1", command=self.update_courses).grid(row=0, column=1, sticky="w")
        ttk.Radiobutton(main_frame, text="Semester 2", variable=self.semester_var,
                        value="2", command=self.update_courses).grid(row=0, column=2, sticky="w")
        self.scroll_frame = ScrollableFrame(main_frame)
        self.scroll_frame.grid(row=1, column=0, columnspan=4, sticky="nsew", pady=10)
        self.course_entries = {}
        param_frame = ttk.Frame(main_frame)
        param_frame.grid(row=2, column=0, columnspan=4, pady=15, sticky="w")
        ttk.Label(param_frame, text="Mutation Rate:").grid(row=0, column=2)
        self.mutation_entry = ttk.Entry(param_frame, width=10)
        self.mutation_entry.insert(0, "0.2")
        self.mutation_entry.grid(row=0, column=3, padx=5)
        ttk.Label(param_frame, text="Generations:").grid(row=0, column=4)
        self.gen_entry = ttk.Entry(param_frame, width=10)
        self.gen_entry.insert(0, "100")
        self.gen_entry.grid(row=0, column=5, padx=5)
        ttk.Button(main_frame, text="Generate Timetable", command=self.generate,style="Accent.TButton").grid(row=3, column=0, columnspan=4, pady=15)
        main_frame.rowconfigure(1, weight=1)
        main_frame.columnconfigure(0, weight=1)
        self.update_courses()
        self._configure_styles()
     
    def focus_next_entry(self, event):  # next field auto 
        current_entry = event.widget
        try:
            index = self.all_entries.index(current_entry)
            next_index = index + 1
            if next_index < len(self.all_entries):
                self.all_entries[next_index].focus_set()
        except ValueError:
            pass
    def show_student_timetable(self, schedule, level):
        window = tk.Toplevel(self.root)
        window.title(f"Level {level} Student Timetable")
        window.geometry("1200x800")
        
        # Filter schedule for this level
        level_courses = [course for course in schedule if course['Level'] == level]
        
        # Create time slots header
        for col, time in enumerate(times):
            ttk.Label(window, text=f"{time}:00", relief="ridge", padding=5).grid(
                row=0, column=col + 1, sticky="nsew")
        
        # Create days column
        for row, day in enumerate(days):
            ttk.Label(window, text=day, relief="ridge", padding=5).grid(
                row=row + 1, column=0, sticky="nsew")
        
        # Fill in the timetable
        schedule_grid = {(day, time): [] for day in days for time in times}
        for session in level_courses:
            schedule_grid[(session['Day'], session['Time'])].append(session)
        
        for row, day in enumerate(days, 1):
            for col, time in enumerate(times, 1):
                cell_frame = ttk.Frame(window, relief="groove", borderwidth=1)
                cell_frame.grid(row=row, column=col, sticky="nsew", padx=1, pady=1)
                sessions = schedule_grid.get((day, time), [])
                for session in sessions:
                    ttk.Label(cell_frame,
                            text=f"{session['Subject']}\nRoom: {session['Room']}",
                            wraplength=150, justify="center").pack(expand=True, fill="both")
        
        # Make cells expand properly
        for i in range(len(times) + 1):
            window.columnconfigure(i, weight=1)
        for i in range(len(days) + 1):
            window.rowconfigure(i, weight=1)
    
    
    
    def plot_fitness(self, fitness_progress):
        pl.figure(figsize=(10, 5))
        pl.plot(fitness_progress, marker='o', color='blue')
        pl.title("Fitness Evolution Over Generations")
        pl.xlabel("Generation")
        pl.ylabel("Best Fitness (Negative Penalty)")
        pl.grid(True)
        pl.tight_layout()
        pl.show()

    def _configure_styles(self):
        style = ttk.Style()
        style.configure("Accent.TButton", foreground="black", background="#4CAF50")
        style.map("Accent.TButton", background=[("active", "#45a049")])

    def update_courses(self):
        for widget in self.scroll_frame.scrollable_frame.winfo_children():
            widget.destroy()
        self.course_entries.clear()
        self.all_entries = []

        semester = self.semester_var.get()
        row_counter = 0

        # Create column headers
        ttk.Label(self.scroll_frame.scrollable_frame, text="Level", font=("Arial", 10, "bold")).grid(row=row_counter, column=0, padx=10, pady=5)
        ttk.Label(self.scroll_frame.scrollable_frame, text="Course Name", font=("Arial", 10, "bold")).grid(row=row_counter, column=1, padx=10, pady=5)
        ttk.Label(self.scroll_frame.scrollable_frame, text="Professor", font=("Arial", 10, "bold")).grid(row=row_counter, column=2, padx=10, pady=5)
        ttk.Label(self.scroll_frame.scrollable_frame, text="Students", font=("Arial", 10, "bold")).grid(row=row_counter, column=3, padx=10, pady=5)
        row_counter += 1

        # Organize courses by level and semester
        for level in range(1, 5):  # Levels 1-4
            level_key = f"level{level}_{semester}"
            if level_key in students:
                # Create level separator
                ttk.Separator(self.scroll_frame.scrollable_frame, orient='horizontal').grid(
                    row=row_counter, column=0, columnspan=4, sticky='ew', pady=5)
                row_counter += 1

                # Add level header
                ttk.Label(self.scroll_frame.scrollable_frame, 
                        text=f"Level {level} - Semester {semester}",
                        font=("Arial", 9, "bold")).grid(row=row_counter, column=0, columnspan=4, sticky='w')
                row_counter += 1

                # Add courses for this level
                for course in students[level_key]:
                    ttk.Label(self.scroll_frame.scrollable_frame, text=f"Level {level}").grid(
                        row=row_counter, column=0, padx=10, pady=3, sticky="w")
                    
                    ttk.Label(self.scroll_frame.scrollable_frame, text=course).grid(
                        row=row_counter, column=1, padx=10, pady=3, sticky="w")
                    
                    prof_entry = ttk.Entry(self.scroll_frame.scrollable_frame, width=25)
                    prof_entry.grid(row=row_counter, column=2, padx=10, pady=3, sticky="w")
                    prof_entry.bind('<Return>', self.focus_next_entry)
                    self.all_entries.append(prof_entry)
                    
                    students_entry = ttk.Entry(self.scroll_frame.scrollable_frame, width=15)
                    students_entry.grid(row=row_counter, column=3, padx=10, pady=3)
                    students_entry.bind('<Return>', self.focus_next_entry)
                    self.all_entries.append(students_entry)
                    
                    self.course_entries[course] = (prof_entry, students_entry)
                    row_counter += 1

        # Add some padding at the bottom
        ttk.Label(self.scroll_frame.scrollable_frame).grid(row=row_counter, column=0, pady=10)
    def validate_inputs(self):
        try:
            mutation_rate = float(self.mutation_entry.get())
            if not 0 <= mutation_rate <= 1:
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "Mutation rate must be between 0 and 1")
            return False
        try:
            generations = int(self.gen_entry.get())
            if generations <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Error", "Generations must be a positive integer")
            return False
        for course, (prof_entry, students_entry) in self.course_entries.items():
            if not prof_entry.get().strip():
                messagebox.showerror("Error", f"Please enter professor name for {course}")
                return False
            try:
                students = int(students_entry.get())
                if students <= 0:
                    raise ValueError
            except ValueError:
                messagebox.showerror("Error", f"Invalid student count for {course}")
                return False
        return True
    def generate(self):
        if not self.validate_inputs():
            return
        sessions = []
        for course, (prof_entry, students_entry) in self.course_entries.items():
            professor = prof_entry.get().strip()
            students_count = int(students_entry.get())
            lectures = math.ceil(students_count / 350)
            subject_prof[course] = professor
            sessions.extend([course] * lectures)
        
        mutation_rate = float(self.mutation_entry.get())
        generations = int(self.gen_entry.get())
        schedule, fitness_progress = run_ga(sessions, gens=generations, mutation_rate=mutation_rate)
        
        # Create level selection window
        level_window = tk.Toplevel(self.root)
        level_window.title("Select Level")
        
        ttk.Label(level_window, text="Choose level to view:").pack(pady=10)
        
        # Get available levels for current semester
        semester = self.semester_var.get()
        available_levels = sorted({
            int(key.split('_')[0][5:])  # Extract level number
            for key in students 
            if key.endswith(f"_{semester}")
        })
        
        # Create buttons for each available level
        for level in available_levels:
            btn = ttk.Button(
                level_window, 
                text=f"Level {level}",
                command=lambda l=level: self.show_student_timetable(schedule, l)
            )
            btn.pack(fill='x', padx=20, pady=5)  # THIS LINE WAS MISSING A PARENTHESIS
        
        # Show main timetable and fitness plot
        self.show_timetable(schedule)
        self.plot_fitness(fitness_progress)


        self.show_timetable(schedule)
        self.plot_fitness(fitness_progress)

    def show_timetable(self, schedule):
        window = tk.Toplevel(self.root)
        window.title("Generated Timetable")
        window.geometry("1200x800")
        for col, time in enumerate(times):
            ttk.Label(window, text=f"{time}:00", relief="ridge", padding=5).grid(
                row=0, column=col + 1, sticky="nsew")
        for row, day in enumerate(days):
            ttk.Label(window, text=day, relief="ridge", padding=5).grid(
                row=row + 1, column=0, sticky="nsew")
        schedule_grid = {(day, time): [] for day in days for time in times}
        for session in schedule:
            schedule_grid[(session['Day'], session['Time'])].append(session)
        for row, day in enumerate(days, 1):
            for col, time in enumerate(times, 1):
                cell_frame = ttk.Frame(window, relief="groove", borderwidth=1)
                cell_frame.grid(row=row, column=col, sticky="nsew", padx=1, pady=1)
                sessions = schedule_grid.get((day, time), [])
                for session in sessions:
                    ttk.Label(cell_frame,text=f"{session['Subject']}\n({session['Professor']})\n{session['Room']}",wraplength=150,justify="center").pack(expand=True, fill="both")
        for i in range(len(times) + 1):
            window.columnconfigure(i, weight=1)
        for i in range(len(days) + 1):
            window.rowconfigure(i, weight=1)


if __name__ == "__main__":
    root = tk.Tk()
    app = TimetableApp(root)
    root.mainloop()

